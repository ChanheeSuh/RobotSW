# Changelog

## 0.0.3 (October 24, 2014)
- resolved authentication problem which occurs in case password length isn't 6

## 0.0.2 (October 21, 2014)
- renewal version-2.0.0 release

## 0.0.1 (April 16, 2014)
- first release
